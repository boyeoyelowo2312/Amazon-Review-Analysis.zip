
---

## 🧠 Project Goal

- Clean and prepare the dataset
- Perform descriptive analysis using Excel
- Visualize key insights with PivotTables, Charts, and Slicers
- Create a summary dashboard to explore product performance

---

## ✅ Steps Taken

### STEP 1: Data Cleaning
- Removed blank rows and checked for invalid values
- Converted columns (e.g., rating, rating_count) to numeric formats
- Created new calculated columns:
  - `Revenue Potential = actual_price * rating_count`
  - `rounded_rating = ROUND(rating, 0)`
  - `price_bucket = IF(actual_price<200, "<₹200", ...)`

### STEP 2: Analysis with PivotTables
Created individual PivotTables and charts to answer:
1. Average discount % by category (Bar Chart)
2. Product count by category (Pie Chart)
3. Total reviews per category
4. Top-rated products (with 100+ reviews)
5. Actual vs discounted prices by category (Column Chart)
6. Products with highest number of reviews
7. Number of products with discount ≥ 50%
8. Distribution of rounded ratings
9. Total revenue potential by category
10. Product count by price bucket
11. Rating vs discount trend (Scatter Plot with Trendline)
12. Products with <1,000 reviews
13. Categories with highest average discounts
14. Top 5 products by rating × log(review count)

### STEP 3: Dashboard Creation
- Moved all charts into a clean **Dashboard** sheet
- Added **KPIs**:
  - Total Products
  - Total Reviews
  - Average Rating
  - Total Revenue Potential
- Inserted **Slicers** for interactivity (e.g., filter by category or price range)
- Used clean layout, grouped related charts, and applied consistent design

---

## 🔍 Key Insights

- **Electronics** had the highest revenue potential but lower discounts
- **Toys** received the most reviews overall
- Products with higher discounts (>50%) didn’t necessarily receive better ratings
- Rating tends to be stable across categories regardless of price
- Only a small number of products are discounted >50%

---

## 📊 Tools Used

- Microsoft Excel (PivotTables, Charts, Slicers)
- Markdown for documentation

---

## 📌 Author

Oyelowo Adeboye  
Capstone Project – DSA Data Analysis  
